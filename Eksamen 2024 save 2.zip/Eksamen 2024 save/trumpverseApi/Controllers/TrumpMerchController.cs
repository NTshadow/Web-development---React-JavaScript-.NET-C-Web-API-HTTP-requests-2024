using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using trumpverseApi.Models;

namespace trumpverseApi.Controllers;

[ApiController]
[Route("api/[controller]")]

public class TrumpMerchController : ControllerBase
{
    private readonly TrumpContext _context; 

    private readonly IWebHostEnvironment hosting;

    public TrumpMerchController(TrumpContext context, IWebHostEnvironment hosting)
    {
        _context = context;
        this.hosting = hosting;
    }

    //Get all merch
    [HttpGet]
    public async Task<ActionResult<IEnumerable<TrumpMerch>>> GetTrumpMerch() 
    {
        return await _context.TrumpMerch.ToListAsync();
    }

    //Get merch by id
    [HttpGet("{id}")]
    public async Task<ActionResult<TrumpMerch>> GetTrumpMerchById(int id )
    {
        var trumpMerch = await _context.TrumpMerch.FindAsync(id);
        if (trumpMerch == null) 
        {
            return NotFound();
        }
        return trumpMerch;
    }
    
    //Get by category
    [HttpGet("category/{category}")]
    public async Task<ActionResult<IEnumerable<TrumpMerch>>> GetByCategory(string category)
    {
        Console.WriteLine($"Category received: {category}");

        
        var merch = await _context.TrumpMerch
                                .Where(t => EF.Functions.Like(t.Category, category))
                                .ToListAsync();

        
        var filteredMerch = merch
            .Where(t => string.Equals(t.Category, category, StringComparison.OrdinalIgnoreCase))
            .ToList();

        if (filteredMerch.Any())
        {
            Console.WriteLine($"Found {filteredMerch.Count} items for category: {category}");
            return Ok(filteredMerch);
        }
        else
        {
            Console.WriteLine($"No items found for category: {category}");
            return NotFound();
        }
    }
    
    //Create new Merch
    [HttpPost]
    public async Task<ActionResult<TrumpMerch>> CreateTrumpMerch(TrumpMerch trumpMerch)
    {
        if (_context.TrumpMerch.Any(e => e.Id == trumpMerch.Id))
        {
            return Conflict(new {message = "Merch with this id aleady exists"});
        }
        
        _context.TrumpMerch.Add(trumpMerch);
        await _context.SaveChangesAsync();

        return CreatedAtAction(nameof(GetTrumpMerchById), new{id = trumpMerch.Id}, trumpMerch);
    }

    //Update exsisting merch
    [HttpPut("{id}")]
    public async Task<ActionResult> UpdateTrumpMerch(int id, TrumpMerch trumpMerch)
    {
        if (id != trumpMerch.Id)
        {
            return BadRequest();
        }
        _context.Entry(trumpMerch).State = Microsoft.EntityFrameworkCore.EntityState.Modified;

        try
        {
            await _context.SaveChangesAsync();
        }
        catch (DbUpdateConcurrencyException)
        {
            if (!_context.TrumpMerch.Any(e => e.Id == id))
            {
                return NotFound();
            }
            else
            {
                throw;
            }
        }
        return NoContent();
    }

    //Delete merch
    [HttpDelete("{id}")]
    public async Task<IActionResult> DeleteTrumpMerch(int id)
    {
        var trumpMerch = await _context.TrumpMerch.FindAsync(id);
        if (trumpMerch == null)
        {
            return NotFound();
        }

        string wwwrootPath = hosting.WebRootPath;
        string imagePath = Path.Combine(wwwrootPath, "images", trumpMerch.ImageUrl);
        
        if(!string.IsNullOrEmpty(trumpMerch.ImageUrl) && System.IO.File.Exists(imagePath)) 
        {
            System.IO.File.Delete(imagePath);
        }
        
        _context.TrumpMerch.Remove(trumpMerch);
        await _context.SaveChangesAsync();

        return NoContent();
    }


}