using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using trumpverseApi.Models;

namespace trumpverseApi.Controllers;

[ApiController]
[Route("api/[controller]")]

public class MerchCartController : ControllerBase
{
    private readonly TrumpContext _context; 

    public MerchCartController(TrumpContext context)
    {
        _context = context ;
    }

    //Get merch 
    [HttpGet]
    public async Task<ActionResult<IEnumerable<MerchCart>>> GetMerchCart()
    {
        return await _context.MerchCart.ToListAsync();
    }

    //Get the merch by id 
    [HttpGet("{id}")]
    public async Task<ActionResult<MerchCart>> GetMerchInCart(int id)
    {
        var merchCart = await _context.MerchCart.FindAsync(id);

        if (merchCart == null)
        {
            return NotFound("Cart item not found!");

        }
        return merchCart;
    }

    //Create Merch in the cart by getting the id
    [HttpPost]
    public async Task<ActionResult<MerchCart>> CreateMerchInCart([FromBody] MerchCart merchCart)
    {
        try
        {
            var existingCartItem = await _context.MerchCart
                .FirstOrDefaultAsync(item => item.Name == merchCart.Name && item.Category == merchCart.Category);

            if (existingCartItem != null)
            {
                existingCartItem.Quantity += merchCart.Quantity;
                _context.Entry(existingCartItem).State = EntityState.Modified;
            }
            else
            {
                _context.MerchCart.Add(merchCart);
            }

            await _context.SaveChangesAsync();
            return CreatedAtAction(nameof(GetMerchInCart), new { id = merchCart.Id }, merchCart);
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error: {ex.Message}\n{ex.StackTrace}");
            return StatusCode(500, "An error occurred while processing your request.");
        }
    }

    //Update Merch in the cart 
    [HttpPut("{id}")]
    public async Task<ActionResult> UpdateMerchCart(int id, [FromBody] MerchCart merchCart)
    {
        if (id != merchCart.Id)
        {
            return BadRequest("Id does not match");
        }

        var existingCartItem = await _context.MerchCart.FindAsync(id);

        if(existingCartItem == null) {
            return NotFound("cart item not found");
        }

        existingCartItem.Quantity = merchCart.Quantity;
        _context.Entry(existingCartItem).State = EntityState.Modified;

        await _context.SaveChangesAsync();
        return NoContent();
    }

    //Delete merch in the cart 
    [HttpDelete("{id}")]
    public async Task<IActionResult> DeleteMerchInCart(int id )
    {
        var merchCart = await _context.MerchCart.FindAsync(id);
        if (merchCart == null)
        {
            return NotFound("Cart item not found!");
        }

        _context.MerchCart.Remove(merchCart);
        await _context.SaveChangesAsync();

        return NoContent();
    }

    //Bool for checking if the id exists in the cart 
    private bool MerchCartExists(int id )
    {
        return _context.MerchCart.Any(e => e.Id == id );
    }

}
