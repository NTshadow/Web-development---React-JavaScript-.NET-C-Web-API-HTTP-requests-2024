using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using trumpverseApi.Models;

namespace trumpverseApi;

[ApiController]
[Route("api/[controller]")]

public class TrumpThoughtController : ControllerBase
{
    private readonly TrumpContext _context; 

    public TrumpThoughtController(TrumpContext context)
    {
        _context = context;
    }

    //Get all thoughts
    [HttpGet]
    public async Task<ActionResult<IEnumerable<TrumpThought>>> GetTrumpThought()
    {
        return await _context.TrumpThoughts.ToListAsync();
    }

    
    //Get all thoughts by id 
    [HttpGet("{id}")]
    public async Task<ActionResult<TrumpThought>> GetTrumpThoughtById(int id )
    {
        var trumpThought = await _context.TrumpThoughts.FindAsync(id);
        if (trumpThought == null) 
        {
            return NotFound();
        }
        return trumpThought;
    }

    //Create new thought 
    [HttpPost]
    public async Task<ActionResult<TrumpThought>> CreateTrumpThought(TrumpThought trumpThought)
    {
        if(_context.TrumpThoughts.Any(e => e.Id == trumpThought.Id))
        {
            return Conflict(new {message = "Thought with this id aleady exists"});
        }
        
        _context.TrumpThoughts.Add(trumpThought);
        await _context.SaveChangesAsync();

        return CreatedAtAction(nameof(GetTrumpThought), new{id = trumpThought.Id}, trumpThought);
    }


    //Delete thought
    [HttpDelete("{id}")]
    public async Task<IActionResult> DeleteTrumpThought(int id)
    {
        var trumpThought = await _context.TrumpThoughts.FindAsync(id);
        if (trumpThought == null)
        {
            return NotFound();
        }

        _context.TrumpThoughts.Remove(trumpThought);
        await _context.SaveChangesAsync();

        return NoContent();
    }

}