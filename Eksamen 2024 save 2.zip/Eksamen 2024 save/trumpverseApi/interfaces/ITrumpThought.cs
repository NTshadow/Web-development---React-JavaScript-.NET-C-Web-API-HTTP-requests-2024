
namespace trumpverseApi.interfaces;

    interface ITrumpThought
    {
        int Id { get; set; }

        string Title { get; set; } 

        string Content { get; set; } 

        string Source { get; set; }
    
        DateOnly DateSaid { get; set; } 
    }
 