
namespace trumpverseApi.interfaces;

interface ITrumpMerch 
{
    int Id {get; set; } 
    string Name {get; set;}  
    string Description {get; set;}
    string Category {get; set;}
    decimal Price {get; set;}  
    string ImageUrl {get; set;}   
}