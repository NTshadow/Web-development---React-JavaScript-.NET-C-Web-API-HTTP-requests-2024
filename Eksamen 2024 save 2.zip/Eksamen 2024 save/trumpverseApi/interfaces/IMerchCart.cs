
namespace trumpverseApi.interfaces;

interface IMerchCart
{
    int Id { get; set; } 
   string Name { get; set; } 
   string Category {get; set; } 
   decimal Price { get; set; }
   string ImageUrl { get; set; } 
   int Quantity { get; set; } 
}