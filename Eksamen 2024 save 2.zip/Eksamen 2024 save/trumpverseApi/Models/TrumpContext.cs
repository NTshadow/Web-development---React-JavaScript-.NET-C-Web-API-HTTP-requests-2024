using Microsoft.EntityFrameworkCore;

public class TrumpContext : DbContext 
{
    public TrumpContext(DbContextOptions<TrumpContext> options ) : base(options) {}

    public DbSet<trumpverseApi.Models.TrumpThought> TrumpThoughts { get; set; }

    public DbSet<trumpverseApi.Models.TrumpMerch> TrumpMerch { get; set; }

    public DbSet<trumpverseApi.Models.MerchCart> MerchCart { get; set; }
}