using System.ComponentModel.DataAnnotations;
using trumpverseApi.interfaces;


namespace trumpverseApi.Models;

    public class TrumpThought : ITrumpThought
    {
        [Key]
        public int Id { get; set; } 

        public string Title { get; set; } = ""; 

        public string Content { get; set; } = ""; 

        public string Source { get; set; } ="";
        
        public DateOnly DateSaid { get; set; } 
    }
 