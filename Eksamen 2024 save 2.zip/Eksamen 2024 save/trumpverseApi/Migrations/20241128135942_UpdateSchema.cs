﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace trumpverseApi.Migrations
{
    /// <inheritdoc />
    public partial class UpdateSchema : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "DatePosted",
                table: "TrumpThoughts",
                newName: "Source");

            migrationBuilder.AddColumn<DateOnly>(
                name: "DateSaid",
                table: "TrumpThoughts",
                type: "TEXT",
                nullable: false,
                defaultValue: new DateOnly(1, 1, 1));
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "DateSaid",
                table: "TrumpThoughts");

            migrationBuilder.RenameColumn(
                name: "Source",
                table: "TrumpThoughts",
                newName: "DatePosted");
        }
    }
}
