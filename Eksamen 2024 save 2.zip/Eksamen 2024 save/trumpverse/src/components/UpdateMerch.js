import React, { useState } from "react";
import { useMerchContext } from "../contexts/MerchContext";
import ImageUploadService from "../services/ImageUploadService.ts";


const UpdateMerch = () => {
    const { updateMerch, fetchMerchById, fetchMerch, categories } = useMerchContext();
    const [selectedId, setSelectedId] = useState("");
    const [updatedMerch, setUpdatedMerch] = useState({
        id: "",
        name: "",
        description:"",
        category: "",
        price: 0,
        imageUrl: "",
    });
    const [image, setImage] = useState(null);
    const [error, setError] = useState(null);
    const [updateMessage, setUpdateMessage] = useState("");
    const [isUpdateVisable, setIsUpdateVisable] = useState(false);

    const handleImageChange =  (e) => {
        const file = e.target.files[0];
        setImage(file);
    };

    const handleGetMerchById = async () => {
        setError("");
        if (!selectedId.trim()) {
            setError("Please enter a valid merch id ")
            setIsUpdateVisable(false);
            return;
        }
        try {
            const merch = await fetchMerchById(selectedId);
            setUpdatedMerch(merch);
            setIsUpdateVisable(true);
        }
        catch (error) {
            setError("Failed to get merch");
            setIsUpdateVisable(false);
        }
    };

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setUpdatedMerch((last) => ({...last, [name]: value, }));
    };


    const handleSubmit = async (e) => {
        e.preventDefault(); 

        if (!updatedMerch || !updatedMerch.id) {
            setError("can not submit: merch id is invalid");
            return;
        }
        try {
            let imageUrl = updatedMerch.imageUrl;

            if(image) {
                const response = await ImageUploadService.uploadImage(image);
                console.log("Image uploaded successfully ", response); 
                imageUrl = response.data.fileName;
            }

            const merchData = {
                ...updatedMerch,
                imageUrl,
            }; 

            console.log("final merch object to update ", merchData);

            await updateMerch(merchData);

            await fetchMerch();

            setIsUpdateVisable(false);
            setUpdateMessage("Merch updated successfully");
        
        } catch (error) {
            setUpdateMessage("Failed to update merch, please try again");
        }
    };

    return (
        <form  onSubmit={handleSubmit} className="border p-4 rounded shadow-md bg-lightIndigo">
            <h2 className="font-bold text-lg mb-4">Update Merch:</h2>
            <div className="mb-4">
                <label className="block text-sm font-bold mb-1">Merch ID:</label>
            <input
                type="text"
                value={selectedId}
                onChange={(e) => setSelectedId(e.target.value)}
                placeholder="Enter Merch ID (then press the button)"
                className="w-full p-2 border rounded mb-2"
            />   
            <button 
                type="button"
                onClick={handleGetMerchById}
                className="bg-gray-500 text-white hover:bg-gray-700 font-bold py-2 px-4 rounded"
            >
                Get Merch by ID
            </button> 
            {error && <p className="text.red.500 mt-2">{error}</p>}
            </div>
            { isUpdateVisable && (
                <>
                <div className="mb-4">
                    <label className="block text-sm font-bold mb-1">Name:</label>
                    <input
                        type="text"
                        name="name"
                        placeholder="Name"
                        value={updatedMerch.name || "" }
                        onChange={handleInputChange}
                        className="w-full p-2 border rounded"
                        required
                    />
                </div>
                <div className="mb-4">
                    <label className="block text-sm font-bold mb-1">Description:</label>
                    <input
                        type="text"
                        name="description"
                        placeholder="Description"
                        value={updatedMerch.description || "" }
                        onChange={handleInputChange}
                        className="w-full p-2 border rounded"
                        required
                    />
                </div>
                <div className="mb-4">
                    <label className="block text-sm font-bold mb-1">Category:</label>
                    <select 
                        name="category"
                        value={updatedMerch.category}
                        onChange={handleInputChange}
                        className="w-full p-2 border rounded"
                        required
                    >
                        <option value="">Select Category</option>
                        {categories.map((cat) => (
                            <option key={cat} value={cat}>
                                {cat}
                            </option>
                        ))}
                    </select>
                </div>
                <div className="mb-4">
                    <label className="block text-sm font-bold mb-1">Price:</label>
                    <input
                        type="number"
                        name="price"
                        placeholder="Price"
                        value={updatedMerch.price || ""}
                        onChange={handleInputChange}
                        className="w-full p-2 border rounded"
                        required
                    />
                </div>
                <label className="block text-sm font-bold mb-1">Change image:</label>
                    <input
                        type="file"
                        accept="image/*"
                        onChange={handleImageChange}
                        className="w-full p-2 border rounded"
                    />
                <button 
                    type="submit"
                    className="bg-blue-700 text-white hover:bg-button font-bold py-2 px-4 rounded"
                >
                    Update Merch
                </button>
                </>
            )}
            {updateMessage && (
                <p 
                    className={`mt-4 ${updateMessage.includes("successfully") ? "text-green-700" : "text-red-700"}`}
                >
                    {updateMessage}
                </p>
            )}
        </form>
    );
};

export default UpdateMerch;