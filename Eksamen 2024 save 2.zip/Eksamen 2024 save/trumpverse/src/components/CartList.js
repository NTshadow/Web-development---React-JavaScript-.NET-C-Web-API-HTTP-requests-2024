import React, { useContext } from "react";
import { MerchCartContext } from "../contexts/MerchCartContext";
import CartItem from "./CartItem";

const CartList = () => {
    const { cart, deleteCartItem, updateCartItem, error } = useContext(MerchCartContext);


    const handlePlus = (id) => {
       const item = cart.find((item) => item.id === id);
       if (item) {
            updateCartItem(id , {...item, quantity: item.quantity + 1 });
       }
    };

    const handleMinus = (id) => {
        const item = cart.find((item) => item.id === id);
       if (item && item.quantity > 1 ) {
            updateCartItem(id , {...item, quantity: item.quantity - 1 });
       }
    };

    const handleRemoveItem = (id) => {
        deleteCartItem(id);
    };

    if (error) {
        return <p className="text-red-500">Error: {error}</p>;
    }

    if (cart.length === 0) {
        return (
            <div className="text-center">
            
                <p>Your cart is currently empty. Add some items to the cart!</p>
            </div>
        );
    }


    return (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {cart.map((item) => (
                    <CartItem
                        key={item.id}
                        item={item}
                        handlePlus={handlePlus}
                        handleMinus={handleMinus}
                        handleRemoveItem={handleRemoveItem}
                    />
                ))}
        </div>
    );
};

export default CartList;
