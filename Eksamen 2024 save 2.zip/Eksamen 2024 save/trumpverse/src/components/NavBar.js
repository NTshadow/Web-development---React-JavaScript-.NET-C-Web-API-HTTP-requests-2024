import { useContext } from "react";
import { Link } from "react-router-dom"
import cart from "../images/cart.svg";
import { MerchCartContext } from "../contexts/MerchCartContext";

import "../App.css";


const NavBar = () => {
    const { getTotalQuantity } = useContext(MerchCartContext);

    const totalCartItems = getTotalQuantity();

    return(
        <nav className="navbar">
           <ul className="navbar__menu">
                <li><Link to ="/">Home</Link></li>
                <li><Link to ="/thoughts">Thoughts</Link></li>
                <li><Link to ="/merch">Merch</Link></li>
            </ul>
            <div className="navbar__cart">
                <Link to ="/merchCart">
                <img src={cart} alt=""/>
                <div className="navbar__cart-count">{totalCartItems}</div>
                </Link> 
            </div>
        </nav>
    )
}

export default NavBar;