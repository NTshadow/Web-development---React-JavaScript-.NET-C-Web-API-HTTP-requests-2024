import React from "react";

const image_url = "http://localhost:5138/images";

const CartItem = ({ item, handlePlus, handleMinus, handleRemoveItem }) => {
    
    return (
        <div className="p-4 rounded shadow-md bg-backgroundSmall">
            <div className="flex flex-row items-start gap-4 bg-backgroundSmall ">
                {/* left side: */}
                <div className="w-1/3">
                    {item.imageUrl ? (
                        <img
                            src={`${image_url}/${item.imageUrl}`}
                            alt={item.name}
                            className="w-full h-48 object-contain rounded mb-4 bg-white"
                            />
                        ) : (
                            <div className="w-full h-48 bg-lightIndigo flex items-center justify-center rounded mb-4">
                                <p className="text-gray-500">No image available</p>
                            </div>
                        )}
                </div>
                {/*right side: */}
                <div className="flex flex-col flex-grow ">
                    <h3 className="text-xl font-bold pb-3">{item.name}</h3>
                    <p>
                        <strong>Category:</strong> {item.category}
                    </p>
                    <p>
                        <strong>Price:</strong> ${item.price.toFixed(2)}
                    </p>
    
                    <div className="flex items-center gap-2 mt-2">
                        <button
                            onClick={() => handleMinus(item.id)}
                            className="bg-white hover:bg-gray-50 font-bold py-1 px-3 rounded"
                        >
                            -
                        </button>
                        <span className="text-lg font-bold">{item.quantity}</span>
                        <button
                            onClick={() => handlePlus(item.id)}
                            className="bg-white hover:bg-gray-50 font-bold py-1 px-3 rounded"
                        >
                            +
                        </button>
                    </div>
        
                    <button
                        onClick={() => handleRemoveItem(item.id)}
                        className="bg-red-700 text-white hover:bg-red-300 font-bold py-1 px-4 rounded mt-2"
                    >
                        Remove from Cart
                    </button>
                </div>  
            </div>
        </div>

    );
};

export default CartItem;