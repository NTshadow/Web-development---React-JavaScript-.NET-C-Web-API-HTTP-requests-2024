import React, { useContext } from "react";
import { ThoughtContext } from "../contexts/ThoughtContext";

const DeleteThought = ({ id }) => {
    const { deleteThought } = useContext(ThoughtContext);

    const handleDelete = async () => {
        if (window.confirm("Are you sure you want to delete this thought? ")) {
            try {
                await deleteThought(id); 
            } catch (error) {
                console.error("Error deleting thought:", error);
            }
        }
    };

    return (
        <button
            onClick={handleDelete}
            className="bg-red-700 text-white hover:bg-red-300 font-bold p-2 rounded"
        >
            Delete
        </button>
    );
};

export default DeleteThought;