import React, { useContext, useState } from "react";
import { MerchCartContext } from "../contexts/MerchCartContext";
import DeleteMerch from "./DeleteMerch";

 const image_url = "http://localhost:5138/images";

const MerchItem = ({ merch }) => {
    const {error, addToCart } = useContext(MerchCartContext);
    const [quantity ] = useState(1);
    const [status, setStatus] = useState("");

    const handleAddToCart = () => {
            try{    
                const cartItem = {
                    id: merch.id,
                    name: merch.name,
                    category: merch.category,
                    price: merch.price,
                    imageUrl: merch.imageUrl,
                    quantity,
                };
            addToCart(cartItem);
            setStatus(`${merch.name} added to cart!`);
        } catch {
            setStatus("Error adding to cart", error);
        }
    };

    return (
        <div className="bg-white border border-gray-200 rounded-lg shadow-md p-4 flex flex-col items-center">
        {merch.imageUrl ? (
            <img
                src={`${image_url}/${merch.imageUrl}`}
                alt={merch.name}
                className="w-full h-48 object-contain rounded mb-4 bg-"
            />
        ) : (
            <div className="w-full h-48 bg-gray-100 flex items-center justify-center rounded mb-4">
                <p className="text-gray-500">No image available</p>
            </div>
        )}
        <h3 className="text-lg font-bold text-center mb-2">{merch.name}</h3>
         <p className="text-sm text-gray-600 mb-1">
            <strong>ID:</strong> {merch.id}
        </p>
        <p className="text-sm text-gray-600 mb-1">
            <strong>Category:</strong> {merch.category}
        </p>
        <p className="text-sm text-gray-600 mb-1 text-center">
            <strong>Description:</strong> {merch.description}
        </p>
        <p className="text-sm text-gray-600 mb-4">
            <strong>Price:</strong> ${merch?.price }
        </p>
        <div className="flex justify-center gap-4 w-full">
            <button
                onClick={handleAddToCart}
                className="bg-green-700 hover:bg-green-300 text-white font-bold py-2 px-4 rounded transition"
            >
                Add to Cart
            </button>
            
            <DeleteMerch id={merch.id} />
        </div>
        {status && <p className="text-green-700 text-lg mt-2">{status}</p>}
    </div>
);
};

export default MerchItem; 