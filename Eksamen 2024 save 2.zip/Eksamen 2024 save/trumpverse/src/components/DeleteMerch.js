import React, { useContext } from "react";
import { MerchContext } from "../contexts/MerchContext";

const DeleteMerch = ({ id }) => {
    const {setMerch, deleteMerch, fetchMerch} = useContext(MerchContext);

    const handleDelete = async () => {
        if (window.confirm("Are you sure you want to delete this merch item? ")) {
            try {
                setMerch((lastMerch) => lastMerch.filter((item) => item.id !== id));

                await deleteMerch(id);
                console.log("Merch deleted successfully!");

            } catch (error) {
                console.error("Failed to delete merch:", error.message);
                await fetchMerch();
            }
        }
    };
    return <button className="bg-red-700 text-white hover:bg-red-300 font-bold p-2 rounded" onClick={handleDelete}>Delete</button>;
};

export default DeleteMerch;