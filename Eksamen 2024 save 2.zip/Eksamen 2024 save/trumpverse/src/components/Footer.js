import React from "react";


const Footer = () => {
    
    return (
            <footer className="bg-navColor w-full h-auto md:h-24">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 md:gap-0 w-full text-white text-center md:text-lg h-full px-4 md:px-0">
                    <div className="hidden md:block"></div>

                    <div className="flex flex-col justify-center items-center">
                        <h2 className="font-bold-50 text-lg md:text-xl">¯\_(ツ)_/¯</h2>
                        <p className="font-bold-50 text-sm md:text-lg">Trumpverse API &copy; 2024. All rights reserved.</p>
                    </div>
    
                    <div className="flex justify-center md:justify-end items-center">
                        <a
                            className="hover:text-blue-500 transition-colors duration-300 p-8 underline text-sm md:text-lg"
                            href="http://localhost:5138"
                        >
                            API Documentation
                        </a>
                    </div>
                </div>
            </footer>
    )
}

export default Footer; 