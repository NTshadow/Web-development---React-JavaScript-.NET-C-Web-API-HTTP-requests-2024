import React, { useContext } from "react";
import { MerchContext } from "../contexts/MerchContext";
import MerchItem from "./MerchItem";

const MerchList = () => {
    const { merch, error } = useContext(MerchContext);

    if (error) {
        return <p className="text-red-700 font-semibold">Error: {error}</p>;
    }

    if (!merch || merch.length === 0) {
        return <p className="text-gray-500 font-medium">No merch Available</p>;
    }

    return (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">

            {merch.map((item, index) => (
                <MerchItem key={item.id || `merch-${index}`} merch={item} />
            ))}
        </div>
    );
};

export default MerchList;