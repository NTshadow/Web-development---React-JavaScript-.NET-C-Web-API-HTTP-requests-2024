import React, { useContext, useState } from "react";
import { ThoughtContext } from "../contexts/ThoughtContext";
import ThoughtService from "../services/ThoughtService";

const AddThought = () => {
    const { addThought } = useContext(ThoughtContext);
    const [status, setStatus ] = useState("");
    const [isSuccessfull, setIsSuccessfull] = useState("");
    const [newThought, setNewThought ] = useState({
        id: "", 
        title: "", 
        content: "", 
        source: "", 
        dateSaid: "",
    });

    const handleInputChange = (e) => {
        const {name, value } = e.target;
        setNewThought({ ...newThought, [name]: value});
    }

    const handleAddThought = async () => {
        setStatus("");

        if (!newThought.title.trim() ) {
            setStatus("Failed to add thought. Title is required");
            setIsSuccessfull(false);
            return; 
        }
        try {
            const existingThought = await ThoughtService.getThoughtById(newThought.id);
            if(existingThought) {
                setStatus("Failed to add thought because id already exists ");
                setIsSuccessfull(false)
                return;
            }
        } catch (error) {
            if(error.response?.status !== 404) {
                console.log("failed to check id existice", error.message);
                setStatus("Failed to create thought because id already exists, please try again");
                setIsSuccessfull(false)
                return;
            }
        }
        try{
            await addThought(newThought);
            setStatus("Thought added successfully!");
            setIsSuccessfull(true)
            setNewThought({
                id: "", 
                title: "", 
                content: "", 
                source: "", 
                dateSaid: "",
            });
    
        } catch (error) {
            setStatus("Error adding thought");
            setIsSuccessfull(false)
        }
    };

    return (
        <form className="p-4">
            <h2 className="font-bold">Add New thought/quote:</h2>
            <br/>
            <div>
            <label className="block text-sm font-bold mb-1">ID</label>
                <input
                    type="number"
                    name="id"
                    placeholder="ID"
                    value={newThought.id}
                    onChange={handleInputChange}
                    className="w-full p-2 border rounded"
                    required
                />
                <label className="block text-sm font-bold mb-1">Title</label>
                <input 
                    type="text"
                    name="title"
                    placeholder="Title"
                    value={newThought.title}
                    onChange={handleInputChange}
                    className="w-full p-2 borderrounded"
                    required
                />
                <label className="block text-sm font-bold mb-1">Content</label>
                <textarea
                    name="content"
                    placeholder="Content"
                    value={newThought.content}
                    onChange={handleInputChange}
                    className="w-full p-2 border rounded"
                    required
                />
                <label className="block text-sm font-bold mb-1">Source</label>
                <input
                    type="text"
                    name="source"
                    placeholder="Source"
                    value={newThought.source}
                    onChange={handleInputChange}
                    className="w-full p-2 border rounded"
                    required
                />
                <label className="block text-sm font-bold mb-1">Date Said</label>
                <input
                    type="date"
                    name="dateSaid"
                    value={newThought.dateSaid}
                    onChange={handleInputChange}
                    className="w-full p-2 border rounded"
                    required
                />
            </div>
            <div className="pt-4">
                <button
                    type="button"
                    onClick={handleAddThought}
                    className="w-full bg-purple-600 text-white hover:bg-purple-400 font-bold p-2 rounded-full"
                >
                    Add Thought
                </button>  
                {status && 
                    <p  className={`mt-4 ${status.includes("Failed to add thought. Title is required ") ? "text-red-700" :  isSuccessfull ? "text-green-700" :"text-red-700" }`}> {status} </p>
                }  
            </div>
        </form>
    );
};

export default AddThought;
