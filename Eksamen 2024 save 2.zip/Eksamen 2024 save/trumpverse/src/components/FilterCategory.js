import React, {useState, useContext} from "react";
import { MerchContext } from "../contexts/MerchContext";


const FilterCategory = () => {
    const { categories, filterMerchByCategory, fetchMerch } = useContext(MerchContext);
    const [selectedCategory, setSelectedCategory] = useState("");

    const handleFilter = () => {
        if (selectedCategory) {
            filterMerchByCategory(selectedCategory);
        } else {
            fetchMerch();
        }
    };

    return (
        <div className="p-4 bg-lightIndigo">
            <h3 className="font-bold text-sm mb-2">Filter by Category</h3>
            
                <select
                    value={selectedCategory}
                    onChange={(e) => setSelectedCategory(e.target.value)}
                    className="w-full p-2 border rounded mb-6"
                >
                    <option value="">All categories</option>
                    {categories.map((category) => (
                        <option key={category} value={category}>
                            {category}
                        </option>
                    ))}
                </select>
               
                <button 
                    onClick={handleFilter}
                    className="bg-blue-700 text-white hover:bg-button font-bold py-2 px-4 rounded w-full"
                >
                    Search
                </button>
    
        </div>
    );
};

export default FilterCategory;