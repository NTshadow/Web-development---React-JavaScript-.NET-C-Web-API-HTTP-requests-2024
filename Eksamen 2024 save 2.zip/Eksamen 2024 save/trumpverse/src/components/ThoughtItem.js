import React from "react";
import DeleteThought from "./DeleteThought";

const ThoughtItem = ({ thought }) => {
    return (
        <li key={thought.id} className="mb-4 border-4 p-3 border-white pb-2">
            <strong>ID:</strong> {thought.id}
            <br />
            <strong>{thought.title}</strong>: {thought.content}
            <br />
            <small>Source: {thought.source}</small> 
            <br />
            <small>Date: {new Date(thought.dateSaid).toLocaleDateString()}</small>
            <br /> 
            <DeleteThought id={thought.id} />
        </li>
    )
}

export default ThoughtItem;