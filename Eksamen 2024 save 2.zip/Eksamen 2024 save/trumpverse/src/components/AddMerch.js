import React, { useState, useContext } from "react";
import { MerchContext } from "../contexts/MerchContext";
import MerchService from "../services/MerchService.js";
import ImageUploadService from "../services/ImageUploadService.ts";

const AddMerch = () => {
    const {  addMerch, categories, setCategories} = useContext(MerchContext);
    const [image, setImage] = useState(null);
    const [addedMessage, setAddedMessage] = useState("");
    const [isSuccessfull, setIsSuccessfull] = useState(null);
    const [newMerch, setNewMerch] = useState({
        id: "",
        name: "",
        description: "",
        category: "",
        price: 0,
        imageUrl: "",
    }); 
    
    const handleImageChange =  (e) => {
        const file = e.target.files[0];
        setImage(file);
    };

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setNewMerch((last) => ({...last, [name]: value }));

        if (name === "category" && value && !categories.includes(value)) {
            setCategories((lastCategories) => [...lastCategories,value ]);
        }
    };


    const handleSubmit = async (e) => {
        e.preventDefault(); 
        setAddedMessage("");
        setIsSuccessfull(null);

        try{
            const existingMerch = await MerchService.getMerchById(newMerch.id);
            if(existingMerch){
                setAddedMessage("Failed to add merch because id already exists ");
                isSuccessfull(false);
                return;
            }
        } catch (error){
            if(error.response?.status !== 404) {
                console.error("failed to check id existice", error.message);
                setAddedMessage("failed to create merch, id already exists, please try again");
                setIsSuccessfull(false);
                return;
            }
        }

        try {
            let imageUrl = newMerch.imageUrl;
    
            if (image) {
                const response = await ImageUploadService.uploadImage(image);
                console.log("Image uploaded successfully", response);
                imageUrl = response.data.fileName; 
            }
    
            const merchData = {
                ...newMerch,
                imageUrl,
            };
    
            await addMerch(merchData);
            setAddedMessage("Merch  added successfully!");
            setIsSuccessfull(true);
            setNewMerch({
                id: "",
                name: "",
                description: "",
                category: "",
                price: 0,
                imageUrl: "",
            });
            setImage(null);
        } catch (error) {
            const errorMessage = 
                error.response?.data?.message || "failed to add merch please try again";
            setAddedMessage(errorMessage);
            setIsSuccessfull(false);
        }
    };

    return (
        <form onSubmit={handleSubmit} 
            className="p-4 border-blue-100 rounded bg-lightIndigo shadow-md grid grid-cols-1 md:grid-cols-2 gap-4"
        >
            {/* left  column */}
            <div className="space-y-4">
                <div>
                    <label className="block text-sm font-bold mb-1">ID</label>
                    <input
                        type="number"
                        name="id"
                        placeholder="ID"
                        value={newMerch.id}
                        onChange={handleInputChange}
                        className="w-full p-2 border rounded"
                        required
                    />
                    </div>
                <div>
                    <label className="block text-sm font-bold mb-1">Name</label>
                    <input
                        type="text"
                        name="name"
                        placeholder="Name"
                        value={newMerch.name}
                        onChange={handleInputChange}
                        className="w-full p-2 border rounded"
                        required
                    />
                </div>
                <div>
                    <label className="block text-sm font-bold mb-1">Category</label>
                    <input
                        type="text"
                        name="category"
                        placeholder="Category"
                        value={newMerch.category}
                        onChange={handleInputChange}
                        list="categories"
                        className="w-full p-2 border rounded"
                        required
                    />
                    <datalist id="categories">
                        {categories.map((category) => (
                            <option key={category} value={category}>
                                {category}
                            </option>
                        ))}
                    </datalist>
                </div>
                <div> 
                    <label className="block text-sm font-bold mb-1">Price</label>
                    <input
                        type="number"
                        name="price"
                        placeholder="Price"
                        value={newMerch.price || ""}
                        onChange={handleInputChange}
                        className="w-full p-2 border rounded"
                        required
                    />
                </div>
                <div className="md:col-span-2">
                    <button
                        type="submit"
                        className="bg-blue-700 text-white hover:bg-button font-bold py-2 px-4 rounded w-full"
                    >
                        Add Merch
                    </button>
                </div>
                {addedMessage && (
                    <p 
                        className={`mt-4 ${isSuccessfull ? "text-green-700" : "text-red-700"}`}
                    >
                        {addedMessage}
                    </p>
                )}

            </div>
            {/*Right  Column*/}
            <div className="space-y-4"> 
                <div className="md:col-span-2">
                    <label className="block text-sm font-bold mb-1">Description</label>
                    <textarea
                        name="description"
                        placeholder="Description"
                        value={newMerch.description}
                        onChange={handleInputChange}
                        className="w-full p-2 border rounded"
                        required
                    />
                </div>
                <div className="md:col-span-2">
                    <label className="block text-sm font-bold mb-1">Upload Image</label>
                    <input
                        type="file"
                        accept="image/*"
                        onChange={handleImageChange}
                        className="w-full p-2 border rounded"
                    />
                </div>
            </div>
        </form>
    );
};

export default AddMerch;