import axios from "axios";


const thought_url = "http://localhost:5138/api/TrumpThought";

const ThoughtService = (() => {
   
    const getAllThoughts = async () =>{
        try {
            const response = await axios.get(thought_url);
            return response.data;
        } catch (error){
            console.error("Failed to fetch all thoughts:", error.message);
            throw error; 
        }
    };

    const getThoughtById = async (id) => {
        try {
            const response = await axios.get(`${thought_url}/${id}`);
            return response.data;
        } catch(error) {
            console.error(`Failed to get thougth with id ${id} `,error.message);
            throw error;
        }
    };

    const addThought = async (newThought) => {
        try{
            const response = await axios.post(thought_url, newThought, {
                headers: {
                    "Content-Type": "application/json",
                },
            });
            return response.data; 
        } catch (error) {
            console.error("Failed to add new thought:", error.message);
            throw error; 
        }
    };

    const deleteThought = async (id) => {
        try{
            await axios.delete(`${thought_url}/${id}`); 
            return true;
        } catch (error) {
            console.error(`Failed to delete thought with ID ${id}:`, error.message);
            throw error;
        }
    }; 

    return{
        getAllThoughts,
        getThoughtById,
        addThought,
        deleteThought,
    };
})(); 

export default ThoughtService; 