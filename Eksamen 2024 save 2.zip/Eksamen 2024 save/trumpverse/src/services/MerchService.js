import axios from "axios";


const merch_url = "http://localhost:5138/api/TrumpMerch";

const MerchService = (() => {
    const getAllMerch = async () => {
        try {
            const response = await axios.get(merch_url);
            return response.data;
        } catch (error) {
            console.error("Failed to get all merch:", error.message);
            throw error;
        }
    };

    const getMerchById = async (id) => {
        try {
            const response = await axios.get(`${merch_url}/${id}`);
            return response.data;
        } catch (error) {
            console.error(`Failed to get merch with ID ${id}:`, error.message);
            throw error;
        }
    };

    const filterMerchByCategory = async (category) => {
        try {
            const response = await axios.get(`${merch_url}/category/${category}`);
            console.log("Filtered Merch:", response.data);
            return response.data;
        } catch (error) {
            console.error(`Failed to filter merch by category "${category}":`, error.message);
            throw error;
        }
    };

    const addMerch = async (newMerch) => {
        try {
            const response = await axios.post(merch_url, newMerch, {
                headers: {
                    "Content-Type": "application/json",
                },
            });
            return response.data;
        } catch (error) {
            console.error("Failed to add new merch:", error.message);
            throw error;
        }
    };

    const deleteMerch = async (id) => {
        try {
            await axios.delete(`${merch_url}/${id}`);
            return true;
        } catch (error) {
            console.error(`Failed to delete merch with ID ${id}:`, error.message);
            throw error;
        }
    };

    const updateMerch = async (updatedMerch) => {
        try {
            const response = await axios.put(`${merch_url}/${updatedMerch.id}`, updatedMerch, {
                headers: {
                    "Content-Type": "application/json",
                },
            });
            return response.data; 
        } catch (error) {
            console.error("Failed to update merch:", error.message);
            throw new Error("Failed to update merch.");
        }
    };

    return {
        getAllMerch,
        getMerchById,
        addMerch,
        deleteMerch,
        updateMerch,
        filterMerchByCategory,
    };
})();

export default MerchService;