import axios from "axios";

const cart_Url = "http://localhost:5138/api/MerchCart";

const MerchCartService = (() => {
   
    const getAllCartItems = async () => {
        const response = await axios.get(cart_Url);
        return response.data;
    };

    const addToCart = async (item) => {
        console.log("Sending payload to backend:", item);
        try {
            const response = await axios.post(cart_Url, item);
            console.log("Response from backend:", response.data);
            return response.data;
        } catch (err) {
            console.error("Error in POST request:", err.response?.data || err.message);
            throw err;
        }
    };
    

    const deleteCartItem = async (id) => {
        await axios.delete(`${cart_Url}/${id}`);
    };

    const clearCart = async () => {
        try{
            const cartItems = await getAllCartItems();
            const deleteCartItems = cartItems.map((item) => axios.delete(`${cart_Url}/${item.id}`));
            await Promise.all(deleteCartItems);
            console.log("cart cleared successfully")
        } catch (error) {
            console.error("Error clearing the cart:", error.response?.data || error.message);
            throw error;
        }
    }

    const updateCartItem = async (id, updatedItem) => {
        try {
            const response = await axios.put(`${cart_Url}/${id}`, updatedItem); 
            return response.data;
        } catch (error) {
            console.error("Error updating cart item:", error);
            throw error;
        }
    };

    return {
        getAllCartItems,
        addToCart,
        clearCart,
        deleteCartItem,
        updateCartItem,
    };
    
})();

export default MerchCartService;