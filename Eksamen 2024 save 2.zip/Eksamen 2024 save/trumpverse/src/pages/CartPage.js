import React, { useContext } from "react";
import { MerchCartContext } from "../contexts/MerchCartContext";
import CartList from "../components/CartList";

const CartPage = () => {
    const { cart, getTotalQuantity, clearCart} = useContext(MerchCartContext);

    const  handleBuy = async () => {
        if (cart.length > 0) {
            alert("You have bought the merch items in your cart!");
            await clearCart();
        } else {
            alert("Your cart is empty. Add merch items before buying!");
        }
    };

    return (
        <div className="container mx-auto p-4">
        <h1 className="text-2xl text-center font-bold mb-4">Your Cart</h1>
        <CartList />
        {cart.length > 0 && (
            <div className="text-center mt-6">
                <h2 className="text-xl font-semibold">Total Items: {getTotalQuantity()}</h2>
                <h2 className="text-xl font-semibold">
                    Total: $
                    {cart.reduce((total, item) => total + item.price * item.quantity, 0).toFixed(2)}
                </h2>
                <button 
                    onClick={handleBuy}
                    className="bg-blue-700 text-white hover:bg-button font-bold py-2 px-4 rounded mt-4"
                >
                    Buy now!!!!
                </button>
            </div>
        )}
    </div>
    );
};

export default CartPage;