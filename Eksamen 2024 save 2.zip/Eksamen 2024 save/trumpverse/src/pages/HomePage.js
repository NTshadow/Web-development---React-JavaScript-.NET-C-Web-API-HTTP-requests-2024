import React from "react";
import trumpHomePage from '../images/trumpHomePage.jpg';


function HomePage() {
    return (
        <div className="text-center flex flex-col p-6 font-sans px-4 md:px-8 lg:px-16">
            <header className="mb-8"> 
                <h1 className="text-3xl font-bold">
                     A Trump universe Web API with database
                </h1>
            </header>
            <br />

            <main className="flex flex-col md:flex-row items-center justify-center gap-10 mb-8 flex-grow h-full ">
                <article className="flex-1 bg-lightIndigo p-14 rounded-lg shadow-md flex items-center justify-center text-center h-full">
                    <p className="text-lg">
                    In this Web API application with a connected database, you can explore an extensive collection of controversial and outrageous statements made by Donald Trump.
                     Additionally, you can shop for anti trump merchandise. 
                    </p>
                </article>
                <section className="flex-1 flex items-center justify-center h-full">
                    <div 
                    className="w-full h-full bg-gray-300 border-2"
                    sans-label="Image placeholder" 
                    > 
                        <img 
                        src={trumpHomePage} 
                        alt="Trump-home-page" 
                        className="h-full w-full object-cover rounded-lg">
                        </img>
                    </div>
                </section>
               
            </main> 
            <br />
            <article className=" flex-1 bg-lightIndigo p-10 rounded-lg shadow-md text-center flex items-center justify-center">
                    <p className="text-lg">
                    You as the user, will able to use the application to it's full extent without any login!!
                     In Trump thoughts you can read all of Trump wise words, create new thoughts and delete a thought. 
                     In Trump merch you can see all merch options, create new merch, delete merch and update an exsisting thougth. 
                     On the same page you can add merch items to the cart, once on the merch cart page you can delete an item form your cart, as well as change the quantity of the merch in the cart.
                    </p>
            </article>
        </div>
    );
}

export default HomePage; 