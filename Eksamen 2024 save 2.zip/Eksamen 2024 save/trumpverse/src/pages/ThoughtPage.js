import React, { useContext} from "react";
import { ThoughtContext } from "../contexts/ThoughtContext";
import AddThought from "../components/AddThought";
import ThoughtItem from "../components/ThoughtItem";

const ThoughtPage = () => {
    const {thoughts } = useContext(ThoughtContext);

    return (
        <div className="px-4 md:px-8 lg:px-16">
            <h1 className="text-3xl font-bold text-center p-6 px-4 md:px-8 lg:px-16"> Trump Thoughts/Quotes</h1>
            <AddThought />
            <br />
            <p className="font-bold"> All Trump Thoughts/Quotes:</p>
            <ul>
                {thoughts.map((thought) => (
                    <ThoughtItem key={thought.id} thought={thought} />
                ))}
            </ul>
        </div>
    );
};

export default ThoughtPage;