import React from "react";
import MerchList from "../components/MerchList";
import AddMerch from "../components/AddMerch";
import UpdateMerch from "../components/UpdateMerch";
import FilterCategory from "../components/FilterCategory";



const MerchPage = () => {

    return (
        <div className="container mx-auto p-8">
            <h1 className="text-3xl font-bold text-center p-6 px-4 md:px-8 lg:px-16">Trump Merch</h1>

            <div className="flex flex-col md:flex-row justify-between gap-7">
                <div className="flex-1">
                    <h2 className="font-bold md-2">Add New Merch:</h2>
                    <AddMerch /> 
                </div>
                <div className="flex justify-center items-center w-full md:w-1/3">
                    <div className="w-80 md:w-96 p-6 border rounded bg-lightIndigo shadow-lg">
                        <FilterCategory />
                    </div>
                </div>
            </div>

            <div className="mb-8 pt-6">
                <h2 className="text-xl font-semibold mb-4">All Available Merch</h2>
                <MerchList />
            </div>
            <div className="mt-8">
                <h2 className="text-xl font-semibold mb-4">Update Existing Merch</h2>
                <UpdateMerch />
            </div>
        </div>
    );
}; 
export default MerchPage;