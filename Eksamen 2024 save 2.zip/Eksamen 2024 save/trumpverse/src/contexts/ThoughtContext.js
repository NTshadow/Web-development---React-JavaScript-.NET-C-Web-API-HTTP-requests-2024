import React, { createContext, useState, useEffect } from "react";
import ThoughtService from "../services/ThoughtService";

const ThoughtContext = createContext(); 

const ThoughtProvider = ({ children }) => {
    const [thoughts, setThoughts] = useState([]);
    const [error, setError] = useState(null);

    const fetchThoughts = async () => {
        try {
            const data = await ThoughtService.getAllThoughts();
            setThoughts(data);
        } catch (error) {
            setError(error.message);
        }
    };

    const addThought = async (newThought) => {
        try {
            const createdThought = await ThoughtService.addThought(newThought);
            setThoughts((lastThoughts) => [...lastThoughts, createdThought]);
        } catch (error) {
            setError(error.message);
            throw error;
        }
    };

    const deleteThought = async (id) => {
        try {
            await ThoughtService.deleteThought(id);
            setThoughts((lastThoughts) => lastThoughts.filter((thought) => thought.id !== id));
        } catch (error) {
            setError(error.message);
            throw error;
        }       
    };

    useEffect(() => {
        fetchThoughts();
    }, []);

    return (
        <ThoughtContext.Provider value={{ thoughts, addThought, deleteThought, error }}>
            {children}
        </ThoughtContext.Provider>
    );
};

export { ThoughtContext, ThoughtProvider };