import React, { createContext, useState, useEffect } from "react";
import MerchCartService from "../services/MerchCartService";


export const MerchCartContext = createContext(); 

export const MerchCartProvider = ({ children }) => {
    const [cart, setCart] = useState([]);
    const [error, setError] = useState(null);

    const fetchCart = async () => {
        try {
            const data = await MerchCartService.getAllCartItems();
            setCart(data);
        } catch (error) {
            setError(error.message);
        }
        
    };

    const addToCart = async (newItem) => {
        try { 
            await MerchCartService.addToCart(newItem);
            fetchCart();
        } catch (error){
            setError(error.message);
        }
    };

    const deleteCartItem = async (id) => {
        try {
            await MerchCartService.deleteCartItem(id);
            setCart((lastCart) => lastCart.filter((item)=> item.id !== id));
        } catch (error) {
            setError(error.message);
        }
    };

    const updateCartItem = async (id, updatedItem) => {
        try {
            await MerchCartService.updateCartItem(id, updatedItem);
            fetchCart();
        } catch (error) {
            setError(error.message);
        }
    };

    const clearCart = async () => {
        try{
            await MerchCartService.clearCart();
            setCart([]);
        }catch (error) {
            setError(error.message);
        }
    }

    const getTotalQuantity = () => {
        return cart.reduce((total, item) => total + item.quantity, 0 );
    };

    useEffect(() => {
        fetchCart();
    }, []);

    return (
        <MerchCartContext.Provider
            value={{cart, setCart, clearCart, addToCart, deleteCartItem, updateCartItem, getTotalQuantity, error }}
        >
            { children }
        </MerchCartContext.Provider>
    );
};