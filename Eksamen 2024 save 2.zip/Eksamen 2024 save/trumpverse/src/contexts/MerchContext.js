import React, {createContext, useContext, useState, useEffect} from "react";
import MerchService from "../services/MerchService";

export const MerchContext = createContext();

export const MerchProvider = ({ children }) => {
    const [merch, setMerch] = useState([]);
    const [categories, setCategories] = useState([]);
    const [error, setError] = useState(null);

    const fetchMerch = async () => {
        try {
            const data = await MerchService.getAllMerch();
            setMerch(data);
            
            const uniqueCategories = [...new Set(data.map((item)=> item.category))];
            setCategories(uniqueCategories);
        } catch (error) {
            setError(error.message);
        }
    };

    const fetchMerchById = async (id) => {
        try {
            const merch = await MerchService.getMerchById(id);
            return merch;
        }
        catch (error) {
            console.error("Failed to fetch merch by ID", error.message);
            throw error;
        }
    }

    const filterMerchByCategory = async (category) => {
        try {
            const data = await MerchService.filterMerchByCategory(category);
            setMerch(data);
        } catch (error) {
            setError(error.message);
            setMerch([]); 
        }
    };

    const addMerch = async (newMerch) => {
        try {
            const createdMerch = await MerchService.addMerch(newMerch);
            setMerch((lastMerch) => [...lastMerch, createdMerch]);

            if (!categories.includes(newMerch.category)){
                setCategories((lastCategories)=> [...lastCategories, newMerch.category]);
            }
        } catch (error) {
            setError("error adding merch:", error);
            throw error;
        }
    };

    const deleteMerch = async (id) => {
        try {
            await MerchService.deleteMerch(id);
            setMerch((lastMerch) => lastMerch.filter((item) => item.id !== id ));
        } catch (error) {
            setError("Failed to delete merch in context:",error.message);
            throw error;
        }
    };


    const updateMerch = async (updatedMerch) => {
        try {
            const updatedItem = await MerchService.updateMerch(updatedMerch);
            setMerch((lastMerch) =>
                lastMerch.map((merch) =>
                    merch.id === updatedMerch.id ? updatedItem : merch
                )
            );
            return updatedItem; 
        } catch (error) {
            setError(error.message);
            throw error;
        }
    };


    useEffect(()=> {
        fetchMerch();
    }, []);

    return (
        <MerchContext.Provider value={{merch, addMerch, setMerch, fetchMerch, fetchMerchById, deleteMerch, updateMerch, categories, setCategories, filterMerchByCategory, error}}>
            {children}
        </MerchContext.Provider>
    );

   
};

export const useMerchContext = () => useContext(MerchContext);