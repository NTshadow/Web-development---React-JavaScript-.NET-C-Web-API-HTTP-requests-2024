import { BrowserRouter, Routes, Route } from "react-router-dom";
import ThoughtPage from "./pages/ThoughtPage";
import HomePage from "./pages/HomePage";
import MerchPage from "./pages/MerchPage";
import CartPage from "./pages/CartPage";
import { ThoughtProvider } from "./contexts/ThoughtContext";
import { MerchProvider } from "./contexts/MerchContext";
import { MerchCartProvider } from "./contexts/MerchCartContext";
import NavBar from "./components/NavBar";
import Footer from "./components/Footer";


function App() {
    return (
        
        <ThoughtProvider>
          <MerchProvider>
            <MerchCartProvider>
                <div className="flex flex-col min-h-screen bg-background">
                <BrowserRouter>
                   <NavBar />
                    <div className="flex-grow">
                        <Routes>
                            <Route path="/" element={<HomePage />}></Route>
                            <Route path="/thoughts" element={<ThoughtPage />}></Route>
                            <Route path="/merch" element={<MerchPage />}></Route>
                            <Route path="/merchCart" element={<CartPage />}></Route>
                            <Route path="*" element={<div>Page Not Found</div>}></Route>
                        </Routes>
                    </div>
                        <Footer />
                    </BrowserRouter>
                </div>
            </MerchCartProvider>
        </MerchProvider>
    </ThoughtProvider>
    );
}

export default App;