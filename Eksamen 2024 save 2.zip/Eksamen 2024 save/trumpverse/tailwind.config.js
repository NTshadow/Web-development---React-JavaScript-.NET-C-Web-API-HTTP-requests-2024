module.exports = {
  content: ["./src/**/*.{js,jsx,ts,tsx}"],
  theme: {
    extend: {
      colors: {
        lightIndigo: '#C0C9DB',
        navColor: '#031A45',
        background:'#e6e7e8',
        button:'#439de6',
        backgroundSmall:'#d8e2f0',
      }
    },
  },
  plugins: [],
};
